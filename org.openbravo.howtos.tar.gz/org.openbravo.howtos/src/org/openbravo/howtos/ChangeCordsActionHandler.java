package org.openbravo.howtos;

import java.math.BigDecimal;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.openbravo.base.exception.OBException;
import org.openbravo.client.kernel.BaseActionHandler;
import org.openbravo.dal.service.OBDal;
import org.openbravo.howtos.HTSalary;

public class ChangeCordsActionHandler extends BaseActionHandler {

  protected JSONObject execute(Map<String, Object> parameters, String data) {
    try {
      final JSONObject jsonData = new JSONObject(data);
      final String cords = jsonData.getString("cords");
      final String recordId = jsonData.getString("id");
      
      final HTSalary salary = OBDal.getInstance().get(HTSalary.class, recordId);
      salary.setCords(cords);
      OBDal.getInstance().save(salary);
      OBDal.getInstance().flush();
      OBDal.getInstance().commitAndClose();
      
      // create the result
      JSONObject json = new JSONObject();
      json.put("total", recordId);

      // and return it
      return json;
    } catch (Exception e) {
      throw new OBException(e);
    }
  }
}
