package org.openbravo.howtos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Collections;

import javax.enterprise.context.ApplicationScoped;

import org.openbravo.client.kernel.BaseComponentProvider;
import org.openbravo.client.kernel.Component;
import org.openbravo.client.kernel.ComponentProvider;
import org.openbravo.client.kernel.KernelConstants;

@ApplicationScoped
@ComponentProvider.Qualifier(HowtosComponentProvider.HOWTOS_VIEW_COMPONENT_TYPE)
public class HowtosComponentProvider extends BaseComponentProvider {
  public static final String HOWTOS_VIEW_COMPONENT_TYPE = "HT_HowtosViewType";

  @Override
  public Component getComponent(String componentId, Map<String, Object> parameters) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public List<ComponentResource> getGlobalComponentResources() {
    final List<ComponentResource> globalResources = new ArrayList<ComponentResource>();
    globalResources.add(createStyleSheetResource("web/org.openbravo.howtos/js/leaflet/leaflet.css", false));
    // globalResources.add(createStyleSheetResource("web/org.openbravo.howtos/js/leaflet/plugins/Coordinates/Leaflet.Coordinates-0.1.5.css",false));
    globalResources.add(createStyleSheetResource("web/org.openbravo.howtos/js/leaflet/plugins/Mouseposition/L.Control.MousePosition.css", false));
    globalResources.add(createStyleSheetResource("web/org.openbravo.userinterface.smartclient/openbravo/skins/" + KernelConstants.SKIN_PARAMETER + "/org.openbravo.howtos/styles.css", false));

    globalResources.add(createStaticResource("web/org.openbravo.howtos/js/leaflet/leaflet.js", false));
    // globalResources.add(createStaticResource("web/org.openbravo.howtos/js/leaflet/plugins/Coordinates/Leaflet.Coordinates-0.1.5.min.js",false));
    globalResources.add(createStaticResource("web/org.openbravo.howtos/js/leaflet/plugins/Mouseposition/L.Control.MousePosition.js", false));
    globalResources.add(createStaticResource("web/org.openbravo.howtos/js/amcharts3/amcharts/amcharts.js", false));
    globalResources.add(createStaticResource("web/org.openbravo.howtos/js/amcharts3/amcharts/serial.js", false));
    globalResources.add(createStaticResource("web/org.openbravo.howtos/js/toolbar-button.js", false));
    globalResources.add(createStaticResource("web/org.openbravo.howtos/js/canvas-field.js", false));

    return globalResources;
  }

  @Override
  public List<String> getTestResources() {
    return Collections.emptyList();
  }
}
