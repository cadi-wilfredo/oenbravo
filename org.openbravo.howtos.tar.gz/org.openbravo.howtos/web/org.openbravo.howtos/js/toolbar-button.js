(function() {
    var buttonProps = {
	action : function() {
	    var callback, view = this.view, grid = view.viewGrid, selectedRecords = grid.getSelectedRecords();
	    var OBEXAPP_HowtosMapPopup = isc.OBPopup.create({
		width : 500,
		height : 500,
		title : "Map Window",
		canDragReposition : true,
		canDragResize : true,
		dismissOnEscape : true,
		dismissOnOutsideClick : true,
		headerControls : ["headerIcon","headerLabel","closeButton"],
		items : [isc.HTMLFlow.create({
		    padding : 1,
		    autoSize : true,
		    contents : '<div id="element_map" style="height:500px;width:500px;cursor: pointer!important;"></div>'
		})],
		initWidget : function() {
		    setTimeout(function() {
			var map = L.map('element_map').setView([51.505,-0.09], 13), markers = {}, onClick = function(latLng) {
			    console.log(latLng)
			    if (selectedRecords.length === 1) {
				OB.RemoteCallManager.call('org.openbravo.howtos.ChangeCordsActionHandler', {
				    id : selectedRecords[0][OB.Constants.ID],
				    cords : JSON.stringify(latLng)
				}, {}, function(rpcResponse, data, rpcRequest) {
				    grid.refreshGrid();
				    if (markers[selectedRecords[0][OB.Constants.ID]].marker)
					markers[selectedRecords[0][OB.Constants.ID]].marker.setLatLng(latLng);
				    else {
					markers[selectedRecords[0][OB.Constants.ID]] = {
					    marker : L.marker(latLng).addTo(map).bindPopup(selectedRecords[0][OB.Constants.IDENTIFIER])
					};
				    }
				});
			    }
			};

			L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1Ijoid2lsODkwNjI1IiwiYSI6ImNqaGpkODZ6cTJoN2IzMG55b3E3aGU2emsifQ.P4FZv3ImqqDMOL_2Ufn53g', {
			    maxZoom : 18,
			    attribution : '',
			    id : 'mapbox.streets',
			    accessToken : 'pk.eyJ1Ijoid2lsODkwNjI1IiwiYSI6ImNqaGpkODZ6cTJoN2IzMG55b3E3aGU2emsifQ.P4FZv3ImqqDMOL_2Ufn53g'
			}).addTo(map);

			for (var i = 0, lng = selectedRecords.length, marker = undefined; i < lng; i++) {
			    // orders.push(selectedRecords[i][OB.Constants.ID]);
			    marker = (selectedRecords[i]['cords']) ? (function() {
				var cordsobj = JSON.parse(selectedRecords[i]['cords']);
				return {
				    marker : L.marker([cordsobj.lat,cordsobj.lng]).addTo(map).bindPopup(selectedRecords[i][OB.Constants.IDENTIFIER])
				};
			    }()) : {
				marker : undefined
			    };
			    markers[selectedRecords[i][OB.Constants.ID]] = marker;
			}

			L.control.mousePosition({
			    clickHandler : onClick
			}).addTo(map);

		    }, 500);
		    this.Super('initWidget', arguments);
		}
	    });
	    OBEXAPP_HowtosMapPopup.show();
	},
	buttonType : 'ht_map',
	prompt : OB.I18N.getLabel('HT_Map'),
	updateState : function() {
	    var view = this.view, form = view.viewForm, grid = view.viewGrid, selectedRecords = grid.getSelectedRecords();
	    if (view.isShowingForm/* && form.isNew */) {
		this.setDisabled(true);
	    } else if (view.isEditingGrid && grid.getEditForm().isNew) {
		this.setDisabled(true);
	    } else {
		this.setDisabled(!selectedRecords.length);
	    }
	}
    };

    // register the button for the sales order tab
    OB.ToolbarRegistry.registerButton(buttonProps.buttonType, isc.OBToolbarIconButton, buttonProps, 200, 'DD1F9D01BE8642898FEA412F3401FB63');

    buttonProps = {
	action : function() {
	    var callback, orders = [], i, view = this.view, grid = view.viewGrid, selectedRecords = grid.getSelectedRecords();

	    isc.HTMLFlow.create({
		ID : 'OBEXAPP_GraphIframe',
		padding : 1,
		autoSize : true,
		contents : '<iframe src="web/org.openbravo.howtos/graph.jsp?info=' + "algo mas" + '" height="500px" width="500px"></iframe>'
	    });

	    var OBEXAPP_HowtosMapPopup = isc.OBPopup.create({
		width : 500,
		height : 500,
		title : "Graph Window",
		canDragReposition : true,
		canDragResize : true,
		dismissOnEscape : true,
		dismissOnOutsideClick : true,
		headerControls : ["headerLabel","closeButton"],
		items : [OBEXAPP_GraphIframe]
	    });

	    OBEXAPP_HowtosMapPopup.show();
	},
	buttonType : 'ht_graph',
	prompt : OB.I18N.getLabel('HT_Graph'),
	updateState : function() {
	    var view = this.view, form = view.viewForm, grid = view.viewGrid, selectedRecords = grid.getSelectedRecords();
	    if (view.isShowingForm && form.isNew) {
		this.setDisabled(true);
	    } else if (view.isEditingGrid && grid.getEditForm().isNew) {
		this.setDisabled(true);
	    } else {
		this.setDisabled(selectedRecords.length === 0);
	    }
	}
    };

    // register the button for the sales order tab
    OB.ToolbarRegistry.registerButton(buttonProps.buttonType, isc.OBToolbarIconButton, buttonProps, 200, 'DD1F9D01BE8642898FEA412F3401FB63');
}());