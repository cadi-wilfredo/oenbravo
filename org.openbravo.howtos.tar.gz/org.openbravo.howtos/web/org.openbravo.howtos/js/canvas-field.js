isc.defineClass('OBEXAPP_HowtosActionButton', isc.OBGridFormButton);

isc.OBEXAPP_HowtosActionButton.addProperties({
    noTitle : true,
    title : "my title",
    click : function() {
	var info = this.record._identifier;
	// if (this.record) {
	// info = this.record._identifier;
	// } else if (this.canvasItem) {
	// info =
	// this.canvasItem.form.getValue(OB.Constants.IDENTIFIER);
	// }
	// isc.say(info);

	isc.HTMLFlow.create({
	    ID : 'OBEXAPP_MapIframe',
	    padding : 1,
	    autoSize : true,
	    contents : '<iframe src="web/org.openbravo.howtos/index.jsp?info=' + info + '" height="500px" width="500px"></iframe>'
	});

	var OBEXAPP_HowtosMapPopup = isc.OBPopup.create({
	    width : 500,
	    height : 500,
	    title : "Map Window",
	    canDragReposition : true,
	    canDragResize : true,
	    dismissOnEscape : true,
	    dismissOnOutsideClick : true,
	    headerControls : ["headerLabel","closeButton"],
	    items : [OBEXAPP_MapIframe]
	});

	OBEXAPP_HowtosMapPopup.show();
    }
});